#!/bin/bash

cp -a /home/. $1 

2>error_cp.log
